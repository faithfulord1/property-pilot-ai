import { useState, useCallback } from "react";

// ── REAL SAMPLE DATA (from uploaded CSVs) ─────────────────────────
const SAMPLE_LEADS = [
  { id:"PL001", address:"14 Thornton Road", postcode:"LS6 2AT", area:"Leeds", type:"Terraced", beds:3, asking:145000, motivation:"Divorce", source:"Rightmove", status:"New Lead", notes:"Below market motivated seller" },
  { id:"PL002", address:"27 Maple Avenue", postcode:"B12 9QR", area:"Birmingham", type:"Semi-Detached", beds:3, asking:175000, motivation:"Relocation", source:"Zoopla", status:"In Progress", notes:"Owner moving abroad urgently" },
  { id:"PL003", address:"8 Coronation Street", postcode:"M4 5JD", area:"Manchester", type:"Terraced", beds:2, asking:130000, motivation:"Probate", source:"Direct Mail", status:"New Lead", notes:"Estate wants quick sale" },
  { id:"PL004", address:"45 Victoria Road", postcode:"NG7 1QR", area:"Nottingham", type:"Semi-Detached", beds:3, asking:158000, motivation:"Financial Difficulty", source:"Referral", status:"Viewing Booked", notes:"Behind on mortgage" },
  { id:"PL005", address:"19 Steel Street", postcode:"S1 2GE", area:"Sheffield", type:"Terraced", beds:3, asking:112000, motivation:"Divorce", source:"Auction", status:"Under Offer", notes:"BMV deal — 72% of value" },
  { id:"PL006", address:"72 Beech Lane", postcode:"LS9 8AB", area:"Leeds", type:"Flat", beds:2, asking:95000, motivation:"Relocation", source:"Rightmove", status:"New Lead", notes:"Tenant in situ" },
  { id:"PL007", address:"33 Park View", postcode:"B15 2TG", area:"Birmingham", type:"Detached", beds:4, asking:285000, motivation:"Retirement", source:"Estate Agent", status:"In Progress", notes:"Long owned — no chain" },
];

const SAMPLE_INVESTORS = [
  { id:"INV001", name:"James Thornton", type:"Cash Buyer", areas:"Leeds, Bradford, Wakefield", budgetMin:80000, budgetMax:200000, strategy:"BTL", status:"Active", deals:8 },
  { id:"INV002", name:"Sarah Blackwell", type:"Portfolio Investor", areas:"Birmingham, Coventry, Wolverhampton", budgetMin:150000, budgetMax:400000, strategy:"BTL", status:"Active", deals:14 },
  { id:"INV003", name:"Michael Chen", type:"Developer", areas:"Manchester, Salford, Trafford", budgetMin:100000, budgetMax:250000, strategy:"Flip", status:"Active", deals:6 },
  { id:"INV004", name:"Priya Patel", type:"HMO Specialist", areas:"Nottingham, Leicester, Derby", budgetMin:120000, budgetMax:300000, strategy:"HMO", status:"Active", deals:11 },
  { id:"INV005", name:"David Morrison", type:"Flip Investor", areas:"Sheffield, Rotherham, Doncaster", budgetMin:80000, budgetMax:180000, strategy:"Flip", status:"Active", deals:9 },
  { id:"INV006", name:"Emma Walsh", type:"BTL Investor", areas:"Leeds, York, Harrogate", budgetMin:100000, budgetMax:220000, strategy:"BTL", status:"Active", deals:5 },
  { id:"INV007", name:"Robert King", type:"BRRR Specialist", areas:"Birmingham, Dudley, Sandwell", budgetMin:130000, budgetMax:350000, strategy:"BRRR", status:"Active", deals:7 },
];

const AREA_DEMAND = { "Leeds":18, "Birmingham":16, "Manchester":19, "Sheffield":14, "Nottingham":15, "Liverpool":13, "Bristol":17, "London":20, "Newcastle":12 };
const MOTIVATION_SCORE = { "Divorce":15, "Probate":15, "Repossession":15, "Financial Difficulty":15, "Relocation":10, "Retirement":8, "Downsizing":7 };

// ── SCORING ENGINE ─────────────────────────────────────────────────
function calculateDeal(p) {
  const totalInvestment = p.purchasePrice + p.refurbCost + p.legalFees + p.stampDuty + p.financeCosts;
  const profit = p.gdv - totalInvestment;
  const roi = totalInvestment > 0 ? (profit / totalInvestment) * 100 : 0;
  const annualRent = (p.monthlyRent || 0) * 12;
  const yieldPct = p.purchasePrice > 0 ? (annualRent / p.purchasePrice) * 100 : 0;
  const cashflow = (p.monthlyRent || 0) - (p.financeCosts / 12) - (p.purchasePrice * 0.001);

  // Weighted Score
  let score = 0;
  if (roi >= 30) score += 25; else if (roi >= 20) score += 18; else if (roi >= 10) score += 10; else if (roi >= 5) score += 4;
  if (yieldPct >= 8) score += 20; else if (yieldPct >= 6) score += 14; else if (yieldPct >= 4) score += 7; else if (yieldPct >= 2) score += 3;
  const locationScore = AREA_DEMAND[p.area] || 10;
  score += locationScore;
  score += MOTIVATION_SCORE[p.vendorMotivation] || 5;
  if (p.strategy) score += 10;
  if (p.gdv > 0) score += 10;
  score = Math.min(Math.round(score), 100);

  const rating = roi >= 25 ? "Strong" : roi >= 15 ? "Good" : roi >= 8 ? "Moderate" : "Avoid";
  const risk = score >= 75 ? "Low" : score >= 50 ? "Medium" : "High";
  const riskReasons = [];
  if (roi < 10) riskReasons.push("ROI below 10% — marginal return");
  if (yieldPct < 5) riskReasons.push("Yield below 5% — cashflow concern");
  if (score >= 75) riskReasons.push("Strong deal score — well-positioned");
  if (MOTIVATION_SCORE[p.vendorMotivation] >= 15) riskReasons.push("Motivated seller — discount potential");
  if (p.gdv > p.purchasePrice * 1.3) riskReasons.push("Strong uplift potential — good GDV margin");

  return { totalInvestment, profit: Math.round(profit), roi: Math.round(roi*100)/100, yieldPct: Math.round(yieldPct*100)/100, cashflow: Math.round(cashflow), score, rating, risk, riskReasons };
}

// ── INVESTOR MATCHING ENGINE ──────────────────────────────────────
function matchInvestors(deal, investors, result) {
  return investors.map(inv => {
    let score = 0; const reasons = [];
    const areas = inv.areas.split(",").map(a => a.trim().toLowerCase());
    if (areas.some(a => deal.area?.toLowerCase().includes(a) || a.includes(deal.area?.toLowerCase()))) {
      score += 30; reasons.push(`Area match: ${inv.areas.split(",")[0].trim()}`);
    }
    if (result.totalInvestment >= inv.budgetMin && result.totalInvestment <= inv.budgetMax) {
      score += 25; reasons.push(`Budget fit: £${(inv.budgetMin/1000).toFixed(0)}k–£${(inv.budgetMax/1000).toFixed(0)}k`);
    } else if (result.totalInvestment <= inv.budgetMax) {
      score += 12; reasons.push("Within max budget");
    }
    if (deal.strategy === inv.strategy) {
      score += 25; reasons.push(`Strategy match: ${inv.strategy}`);
    }
    score += 15; reasons.push("Active investor — recently engaged");
    score = Math.min(score, 100);
    return { ...inv, matchScore: score, reasons };
  }).sort((a,b) => b.matchScore - a.matchScore).slice(0,3);
}

// ── AI SUMMARY GENERATOR (deterministic, no API needed for demo) ──
function generateSummary(deal, result) {
  const strategyMap = { BTL:"buy-to-let", Flip:"flip and sell", HMO:"HMO conversion", BRRR:"BRRR strategy", SA:"serviced accommodation" };
  const strat = strategyMap[deal.strategy] || deal.strategy;
  const profitStr = result.profit >= 0 ? `£${result.profit.toLocaleString()} profit` : "negative return";
  return `**${deal.area} ${deal.type} | AI Deal Score: ${result.score}/100 | ${result.rating}**

${deal.address}, ${deal.postcode} is presented as a ${strat} opportunity in ${deal.area}. The vendor is motivated by ${deal.vendorMotivation?.toLowerCase() || "personal circumstances"}, creating a negotiation window below market value.

**Financial Summary:** Purchase price £${deal.purchasePrice.toLocaleString()} with £${deal.refurbCost.toLocaleString()} refurbishment produces a total investment of £${result.totalInvestment.toLocaleString()} against a GDV of £${deal.gdv.toLocaleString()}, delivering ${profitStr} and a ${result.roi}% ROI. ${deal.monthlyRent ? `Projected rental income of £${deal.monthlyRent.toLocaleString()}/month generates a ${result.yieldPct}% gross yield with £${result.cashflow}/month cashflow.` : ""}

**Why This Deal Works:** ${result.rating === "Strong" || result.rating === "Good" ? `Strong fundamentals — above-average ROI in a high-demand rental market. ${deal.area} demonstrates consistent tenant demand and rental growth.` : `Moderate fundamentals — suitable for the right investor profile. Due diligence on comparables recommended.`}

**Risk Assessment:** ${result.risk} Risk. ${result.riskReasons.join(". ")}.`;
}

// ── COLOUR HELPERS ────────────────────────────────────────────────
const scoreColor  = s => s >= 75 ? "#1E8449" : s >= 50 ? "#D4850D" : "#C0392B";
const riskBg      = r => r === "Low" ? "#EAF3DE" : r === "Medium" ? "#FAEEDA" : "#FCEBEB";
const riskText    = r => r === "Low" ? "#27500A" : r === "Medium" ? "#633806" : "#501313";
const ratingBg    = r => r === "Strong" ? "#EAF3DE" : r === "Good" ? "#E6F1FB" : r === "Moderate" ? "#FAEEDA" : "#FCEBEB";
const ratingText  = r => r === "Strong" ? "#27500A" : r === "Good" ? "#0C447C" : r === "Moderate" ? "#633806" : "#501313";

// ── COMPONENTS ────────────────────────────────────────────────────
function Badge({ label, bg, color }) {
  return <span style={{ background: bg, color, fontSize: 12, fontWeight: 500, padding: "3px 10px", borderRadius: 20, display:"inline-block" }}>{label}</span>;
}

function ScoreCircle({ score, size = 72 }) {
  const col = scoreColor(score);
  return (
    <div style={{ width: size, height: size, borderRadius: "50%", border: `3px solid ${col}`, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
      <span style={{ fontSize: size * 0.32, fontWeight:700, color:col, lineHeight:1 }}>{score}</span>
      <span style={{ fontSize: 10, color:"var(--color-text-secondary)" }}>/ 100</span>
    </div>
  );
}

function KPICard({ icon, label, value, sub, color }) {
  return (
    <div style={{ background:"var(--color-background-secondary)", borderRadius:"var(--border-radius-md)", padding:"14px 16px", display:"flex", flexDirection:"column", gap:4 }}>
      <span style={{ fontSize:13, color:"var(--color-text-secondary)" }}>{icon} {label}</span>
      <span style={{ fontSize:24, fontWeight:500, color: color||"var(--color-text-primary)" }}>{value}</span>
      {sub && <span style={{ fontSize:12, color:"var(--color-text-secondary)" }}>{sub}</span>}
    </div>
  );
}

function SectionHeader({ num, title, subtitle }) {
  return (
    <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:20 }}>
      <div style={{ width:40, height:40, borderRadius:"50%", background:"#0D1B3E", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
        <span style={{ color:"#C9A84C", fontWeight:700, fontSize:16 }}>{num}</span>
      </div>
      <div>
        <div style={{ fontWeight:500, fontSize:17, color:"var(--color-text-primary)" }}>{title}</div>
        {subtitle && <div style={{ fontSize:13, color:"var(--color-text-secondary)", marginTop:2 }}>{subtitle}</div>}
      </div>
    </div>
  );
}

// ── AGENT 1: DEAL ANALYSER ────────────────────────────────────────
function Agent1({ onResult }) {
  const [form, setForm] = useState({
    address:"14 Thornton Road, Leeds", postcode:"LS6 2AT", area:"Leeds",
    type:"Terraced", beds:3, vendorMotivation:"Divorce",
    purchasePrice:125000, refurbCost:18000, gdv:165000,
    legalFees:2500, stampDuty:0, financeCosts:6200,
    monthlyRent:840, strategy:"BTL"
  });
  const [result, setResult] = useState(null);
  const [running, setRunning] = useState(false);

  const run = useCallback(() => {
    setRunning(true);
    setTimeout(() => {
      const r = calculateDeal(form);
      setResult(r);
      onResult?.({ deal: form, result: r });
      setRunning(false);
    }, 800);
  }, [form, onResult]);

  const set = (k,v) => setForm(f => ({ ...f, [k]: isNaN(v) || v === "" ? v : Number(v) }));

  const inputStyle = { width:"100%", fontSize:14, boxSizing:"border-box" };
  const labelStyle = { fontSize:12, color:"var(--color-text-secondary)", marginBottom:4, display:"block" };
  const col2 = { display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 };

  return (
    <div>
      <SectionHeader num="1" title="Deal Analyser Agent" subtitle="Enter deal inputs → AI calculates ROI, profit, risk score, and investment rating" />
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:24 }}>
        {/* LEFT: INPUTS */}
        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
          <div style={{ background:"var(--color-background-secondary)", borderRadius:"var(--border-radius-lg)", padding:16 }}>
            <p style={{ fontSize:13, fontWeight:500, marginBottom:12, color:"var(--color-text-secondary)" }}>Property Details</p>
            <div style={{ marginBottom:10 }}>
              <label style={labelStyle}>Address</label>
              <input value={form.address} onChange={e=>set("address",e.target.value)} style={inputStyle} />
            </div>
            <div style={col2}>
              <div><label style={labelStyle}>Area / City</label>
                <select value={form.area} onChange={e=>set("area",e.target.value)} style={inputStyle}>
                  {Object.keys(AREA_DEMAND).map(a=><option key={a}>{a}</option>)}
                </select>
              </div>
              <div><label style={labelStyle}>Type</label>
                <select value={form.type} onChange={e=>set("type",e.target.value)} style={inputStyle}>
                  {["Terraced","Semi-Detached","Detached","Flat","HMO","Commercial"].map(t=><option key={t}>{t}</option>)}
                </select>
              </div>
            </div>
            <div style={col2}>
              <div><label style={labelStyle}>Vendor Motivation</label>
                <select value={form.vendorMotivation} onChange={e=>set("vendorMotivation",e.target.value)} style={inputStyle}>
                  {Object.keys(MOTIVATION_SCORE).map(m=><option key={m}>{m}</option>)}
                </select>
              </div>
              <div><label style={labelStyle}>Strategy</label>
                <select value={form.strategy} onChange={e=>set("strategy",e.target.value)} style={inputStyle}>
                  {["BTL","Flip","HMO","BRRR","SA"].map(s=><option key={s}>{s}</option>)}
                </select>
              </div>
            </div>
          </div>

          <div style={{ background:"var(--color-background-secondary)", borderRadius:"var(--border-radius-lg)", padding:16 }}>
            <p style={{ fontSize:13, fontWeight:500, marginBottom:12, color:"var(--color-text-secondary)" }}>Financial Inputs</p>
            <div style={col2}>
              <div><label style={labelStyle}>Purchase Price (£)</label><input type="number" value={form.purchasePrice} onChange={e=>set("purchasePrice",e.target.value)} style={inputStyle} /></div>
              <div><label style={labelStyle}>Refurb Cost (£)</label><input type="number" value={form.refurbCost} onChange={e=>set("refurbCost",e.target.value)} style={inputStyle} /></div>
              <div><label style={labelStyle}>GDV (£)</label><input type="number" value={form.gdv} onChange={e=>set("gdv",e.target.value)} style={inputStyle} /></div>
              <div><label style={labelStyle}>Monthly Rent (£)</label><input type="number" value={form.monthlyRent} onChange={e=>set("monthlyRent",e.target.value)} style={inputStyle} /></div>
              <div><label style={labelStyle}>Legal Fees (£)</label><input type="number" value={form.legalFees} onChange={e=>set("legalFees",e.target.value)} style={inputStyle} /></div>
              <div><label style={labelStyle}>Stamp Duty (£)</label><input type="number" value={form.stampDuty} onChange={e=>set("stampDuty",e.target.value)} style={inputStyle} /></div>
              <div><label style={labelStyle}>Finance Costs (£)</label><input type="number" value={form.financeCosts} onChange={e=>set("financeCosts",e.target.value)} style={inputStyle} /></div>
            </div>
          </div>

          <button onClick={run} disabled={running} style={{ background:"#0D1B3E", color:"#C9A84C", border:"none", padding:"14px 20px", borderRadius:"var(--border-radius-md)", fontWeight:500, fontSize:15, cursor:running?"wait":"pointer", letterSpacing:0.5 }}>
            {running ? "⏳ Analysing deal…" : "▶ Run AI Analysis"}
          </button>
        </div>

        {/* RIGHT: RESULTS */}
        <div>
          {!result && (
            <div style={{ background:"var(--color-background-secondary)", borderRadius:"var(--border-radius-lg)", padding:32, textAlign:"center", color:"var(--color-text-secondary)", height:"100%", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:12 }}>
              <div style={{ fontSize:40 }}>📊</div>
              <p style={{ fontSize:15, fontWeight:500 }}>Results appear here</p>
              <p style={{ fontSize:13 }}>Enter deal details and click Run AI Analysis</p>
            </div>
          )}
          {result && (
            <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
              {/* Score + Rating headline */}
              <div style={{ background:"var(--color-background-primary)", border:"0.5px solid var(--color-border-tertiary)", borderRadius:"var(--border-radius-lg)", padding:20, display:"flex", alignItems:"center", gap:20 }}>
                <ScoreCircle score={result.score} size={80} />
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:13, color:"var(--color-text-secondary)", marginBottom:6 }}>AI Deal Score</div>
                  <div style={{ display:"flex", gap:8, flexWrap:"wrap", marginBottom:8 }}>
                    <Badge label={result.rating} bg={ratingBg(result.rating)} color={ratingText(result.rating)} />
                    <Badge label={`${result.risk} Risk`} bg={riskBg(result.risk)} color={riskText(result.risk)} />
                  </div>
                  <div style={{ fontSize:12, color:"var(--color-text-secondary)" }}>{result.riskReasons[0]}</div>
                </div>
              </div>

              {/* Financials grid */}
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
                <KPICard icon="💰" label="Total Investment" value={`£${result.totalInvestment.toLocaleString()}`} />
                <KPICard icon="📈" label="Profit (GDV − Cost)" value={`£${result.profit.toLocaleString()}`} color={result.profit > 0 ? "#1E8449" : "#C0392B"} />
                <KPICard icon="🎯" label="ROI %" value={`${result.roi}%`} color={result.roi >= 20 ? "#1E8449" : result.roi >= 10 ? "#D4850D" : "#C0392B"} />
                <KPICard icon="🏠" label="Gross Yield" value={`${result.yieldPct}%`} color={result.yieldPct >= 7 ? "#1E8449" : result.yieldPct >= 5 ? "#D4850D" : "#C0392B"} />
                <KPICard icon="💵" label="Monthly Cashflow" value={`£${result.cashflow}`} color={result.cashflow > 0 ? "#1E8449" : "#C0392B"} />
                <KPICard icon="📊" label="GDV" value={`£${form.gdv.toLocaleString()}`} />
              </div>

              {/* Risk reasons */}
              <div style={{ background: riskBg(result.risk), borderLeft:`4px solid ${riskText(result.risk)}`, borderRadius:"0 var(--border-radius-md) var(--border-radius-md) 0", padding:"12px 16px" }}>
                <p style={{ fontSize:13, fontWeight:500, color:riskText(result.risk), marginBottom:8 }}>Risk Assessment — {result.risk} Risk</p>
                {result.riskReasons.map((r,i) => <p key={i} style={{ fontSize:12, color:riskText(result.risk), margin:"2px 0" }}>• {r}</p>)}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── AGENT 2: INVESTOR MATCHER ─────────────────────────────────────
function Agent2({ prefill }) {
  const [selected, setSelected] = useState(prefill?.deal || SAMPLE_LEADS[0]);
  const [matches, setMatches] = useState(null);
  const [running, setRunning] = useState(false);

  const run = useCallback(() => {
    setRunning(true);
    setTimeout(() => {
      const dealResult = prefill?.result || calculateDeal({
        ...selected,
        purchasePrice: selected.asking * 0.85,
        refurbCost: 15000, gdv: selected.asking * 1.1,
        legalFees: 2500, stampDuty: 0, financeCosts: 5000,
        monthlyRent: Math.round(selected.asking * 0.005),
        strategy: "BTL", vendorMotivation: selected.motivation,
        area: selected.area
      });
      const m = matchInvestors(selected, SAMPLE_INVESTORS, dealResult);
      setMatches(m);
      setRunning(false);
    }, 700);
  }, [selected, prefill]);

  return (
    <div>
      <SectionHeader num="2" title="Investor Matcher Agent" subtitle="Select a property → AI matches the top 3 investors by area, budget, strategy, and activity" />

      <div style={{ marginBottom:16 }}>
        <label style={{ fontSize:13, color:"var(--color-text-secondary)", marginBottom:6, display:"block" }}>Select property to match:</label>
        <select value={selected.id} onChange={e => setSelected(SAMPLE_LEADS.find(l=>l.id===e.target.value))}
          style={{ width:"100%", fontSize:14 }}>
          {SAMPLE_LEADS.map(l => <option key={l.id} value={l.id}>{l.address}, {l.area} — {l.motivation}</option>)}
        </select>
      </div>

      <div style={{ background:"var(--color-background-secondary)", borderRadius:"var(--border-radius-md)", padding:"12px 16px", marginBottom:16, display:"flex", gap:16, flexWrap:"wrap" }}>
        <span style={{ fontSize:13, color:"var(--color-text-secondary)" }}>📍 {selected.area}</span>
        <span style={{ fontSize:13, color:"var(--color-text-secondary)" }}>🏠 {selected.type} · {selected.beds} bed</span>
        <span style={{ fontSize:13, color:"var(--color-text-secondary)" }}>💷 £{selected.asking.toLocaleString()}</span>
        <span style={{ fontSize:13, color:"var(--color-text-secondary)" }}>⚡ {selected.motivation}</span>
      </div>

      <button onClick={run} disabled={running} style={{ background:"#0D1B3E", color:"#C9A84C", border:"none", padding:"12px 20px", borderRadius:"var(--border-radius-md)", fontWeight:500, fontSize:14, cursor:running?"wait":"pointer", marginBottom:20 }}>
        {running ? "⏳ Matching investors…" : "▶ Match Investors"}
      </button>

      {matches && (
        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
          {matches.map((inv, i) => (
            <div key={inv.id} style={{ background:"var(--color-background-primary)", border:`0.5px solid ${i===0?"#C9A84C":"var(--color-border-tertiary)"}`, borderRadius:"var(--border-radius-lg)", padding:16, display:"flex", gap:16, alignItems:"flex-start" }}>
              {/* Rank + Score */}
              <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:4, minWidth:52 }}>
                <div style={{ width:36, height:36, borderRadius:"50%", background: i===0?"#C9A84C": i===1?"#D0D5DE":"#F4F6F9", display:"flex", alignItems:"center", justifyContent:"center", fontWeight:700, fontSize:16, color: i===0?"#0D1B3E":"#5F5E5A" }}>#{i+1}</div>
                <div style={{ fontSize:11, color:"var(--color-text-secondary)", textAlign:"center" }}>match</div>
              </div>
              {/* Info */}
              <div style={{ flex:1 }}>
                <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:6, flexWrap:"wrap" }}>
                  <span style={{ fontWeight:500, fontSize:15 }}>{inv.name}</span>
                  <Badge label={inv.strategy} bg="#E6F1FB" color="#0C447C" />
                  <Badge label={`${inv.deals} deals`} bg="#EAF3DE" color="#27500A" />
                  {i === 0 && <Badge label="Best Match" bg="#C9A84C" color="#0D1B3E" />}
                </div>
                <div style={{ fontSize:12, color:"var(--color-text-secondary)", marginBottom:8 }}>
                  {inv.type} · Budget: £{(inv.budgetMin/1000).toFixed(0)}k–£{(inv.budgetMax/1000).toFixed(0)}k · {inv.areas}
                </div>
                {/* Match Score Bar */}
                <div style={{ marginBottom:8 }}>
                  <div style={{ display:"flex", justifyContent:"space-between", fontSize:12, marginBottom:4 }}>
                    <span style={{ color:"var(--color-text-secondary)" }}>Match Score</span>
                    <span style={{ fontWeight:500, color: scoreColor(inv.matchScore) }}>{inv.matchScore}%</span>
                  </div>
                  <div style={{ height:6, background:"var(--color-background-secondary)", borderRadius:3, overflow:"hidden" }}>
                    <div style={{ height:"100%", width:`${inv.matchScore}%`, background: scoreColor(inv.matchScore), borderRadius:3, transition:"width 0.6s ease" }} />
                  </div>
                </div>
                {/* Reasons */}
                <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                  {inv.reasons.map((r,j) => <span key={j} style={{ fontSize:11, background:"var(--color-background-secondary)", padding:"3px 8px", borderRadius:20, color:"var(--color-text-secondary)" }}>✓ {r}</span>)}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── AGENT 3: PROPERTY SUMMARY GENERATOR ──────────────────────────
function Agent3({ prefill }) {
  const [selected, setSelected] = useState(prefill?.deal ? null : SAMPLE_LEADS[0]);
  const [summary, setSummary] = useState(null);
  const [running, setRunning] = useState(false);
  const [copied, setCopied] = useState(false);

  const activeDeal = selected || prefill?.deal;
  const activeResult = prefill?.result;

  const run = useCallback(() => {
    setRunning(true);
    setTimeout(() => {
      const deal = {
        ...activeDeal,
        purchasePrice: activeDeal.asking * 0.86,
        refurbCost: 16000, gdv: activeDeal.asking * 1.12,
        legalFees: 2500, stampDuty: 0, financeCosts: 5500,
        monthlyRent: Math.round(activeDeal.asking * 0.0055),
        strategy: "BTL", vendorMotivation: activeDeal.motivation,
        area: activeDeal.area,
        type: activeDeal.type
      };
      const result = activeResult || calculateDeal(deal);
      setSummary(generateSummary(deal, result));
      setRunning(false);
    }, 1200);
  }, [activeDeal, activeResult]);

  const copy = () => {
    navigator.clipboard?.writeText(summary.replace(/\*\*/g,""));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const renderMd = txt => txt.split("\n").map((line, i) => {
    const bold = line.replace(/\*\*(.*?)\*\*/g, (_, m) => `<strong>${m}</strong>`);
    return <p key={i} style={{ margin:"0 0 6px", fontSize:14, lineHeight:1.7, color:"var(--color-text-primary)" }} dangerouslySetInnerHTML={{ __html: bold || "&nbsp;" }} />;
  });

  return (
    <div>
      <SectionHeader num="3" title="Property Summary Generator" subtitle="Generates a professional investor-ready deal pack in seconds — powered by AI" />

      {!prefill?.deal && (
        <div style={{ marginBottom:16 }}>
          <label style={{ fontSize:13, color:"var(--color-text-secondary)", marginBottom:6, display:"block" }}>Select property:</label>
          <select value={selected?.id} onChange={e => setSelected(SAMPLE_LEADS.find(l=>l.id===e.target.value))}
            style={{ width:"100%", fontSize:14 }}>
            {SAMPLE_LEADS.map(l => <option key={l.id} value={l.id}>{l.address}, {l.area}</option>)}
          </select>
        </div>
      )}

      {prefill?.deal && (
        <div style={{ background:"var(--color-background-secondary)", borderRadius:"var(--border-radius-md)", padding:"10px 14px", marginBottom:14, fontSize:13, color:"var(--color-text-secondary)" }}>
          ✓ Using deal from Agent 1: {prefill.deal.address} — Score {prefill.result?.score}/100
        </div>
      )}

      <button onClick={run} disabled={running} style={{ background:"#0D1B3E", color:"#C9A84C", border:"none", padding:"12px 20px", borderRadius:"var(--border-radius-md)", fontWeight:500, fontSize:14, cursor:running?"wait":"pointer", marginBottom:20 }}>
        {running ? "⏳ Generating deal pack…" : "▶ Generate AI Deal Pack"}
      </button>

      {summary && (
        <div>
          <div style={{ background:"var(--color-background-primary)", border:"0.5px solid var(--color-border-tertiary)", borderRadius:"var(--border-radius-lg)", padding:20, marginBottom:10 }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:14, paddingBottom:12, borderBottom:"0.5px solid var(--color-border-tertiary)" }}>
              <div>
                <span style={{ fontSize:12, fontWeight:500, background:"#0D1B3E", color:"#C9A84C", padding:"3px 10px", borderRadius:20 }}>INVESTOR BRIEF</span>
                <span style={{ fontSize:11, color:"var(--color-text-secondary)", marginLeft:10 }}>PropertyPilot AI™ · {new Date().toLocaleDateString("en-GB")}</span>
              </div>
              <button onClick={copy} style={{ fontSize:12, padding:"6px 12px", borderRadius:"var(--border-radius-md)" }}>
                {copied ? "✓ Copied" : "Copy"}
              </button>
            </div>
            <div>{renderMd(summary)}</div>
          </div>
          <div style={{ background:"#E6F1FB", borderRadius:"var(--border-radius-md)", padding:"10px 14px", fontSize:12, color:"#0C447C" }}>
            ℹ This summary was generated by PropertyPilot AI™. All figures should be independently verified before investor communication. Compliant with ICO AI transparency guidance.
          </div>
        </div>
      )}
    </div>
  );
}

// ── POWER BI DASHBOARD (Visual Guide) ────────────────────────────
function PowerBIDashboard() {
  const [activeTab, setActiveTab] = useState("executive");
  const tabs = [
    { id:"executive", label:"Executive", icon:"📊" },
    { id:"deals", label:"Deal Analysis", icon:"🏠" },
    { id:"investors", label:"Investors", icon:"👥" },
    { id:"risk", label:"Risk", icon:"⚠️" },
    { id:"revenue", label:"Revenue", icon:"💰" },
    { id:"setup", label:"PBI Setup", icon:"🔧" },
  ];

  // ── Use real aggregated CSV data ──
  const kpis = { totalDeals:100, totalFees:498450, activeInvestors:42, completed:25, avgROI:14.8, highRisk:18, pipeline:3240000 };
  const feesByMonth = [
    { m:"Jan", v:18000 },{ m:"Feb", v:24500 },{ m:"Mar", v:31000 },{ m:"Apr", v:28500 },
    { m:"May", v:42000 },{ m:"Jun", v:38500 },{ m:"Jul", v:51000 },{ m:"Aug", v:45000 },
  ];
  const dealsByStatus = [
    { s:"New Lead", n:32, col:"#378ADD" },{ s:"In Progress", n:28, col:"#1A7F8E" },
    { s:"Under Offer", n:15, col:"#D4850D" },{ s:"Completed", n:25, col:"#1E8449" },
  ];
  const roiByArea = [
    { area:"Sheffield", roi:19.4 },{ area:"Leeds", roi:16.8 },{ area:"Manchester", roi:15.2 },
    { area:"Nottingham", roi:14.9 },{ area:"Birmingham", roi:13.6 },{ area:"Liverpool", roi:12.1 },
  ];
  const strategyData = [
    { s:"BTL", n:42, avgROI:13.2 },{ s:"Flip", n:28, avgROI:19.7 },
    { s:"HMO", n:18, avgROI:18.1 },{ s:"BRRR", n:12, avgROI:22.4 },
  ];
  const riskDist = [{ r:"Low", n:42, col:"#1E8449" },{ r:"Medium", n:40, col:"#D4850D" },{ r:"High", n:18, col:"#C0392B" }];
  const dax = [
    { label:"Total Deals", formula:"COUNTROWS(property_leads)" },
    { label:"Total Fees", formula:'SUM(sourcing_fees[Agreed_Fee])' },
    { label:"Fees Collected", formula:'CALCULATE([Total Fees], sourcing_fees[Payment_Status]="Paid")' },
    { label:"Active Investors", formula:'CALCULATE(COUNTROWS(investor_buyers), investor_buyers[Status]="Active")' },
    { label:"Avg ROI %", formula:"AVERAGE(deal_analysis[ROI_Percent])" },
    { label:"Avg AI Score", formula:"AVERAGE(deal_analysis[Deal_Score])" },
    { label:"High Risk Deals", formula:'CALCULATE(COUNTROWS(deal_analysis), deal_analysis[Risk_Level]="High")' },
    { label:"Fee Collection %", formula:"DIVIDE([Fees Collected], [Total Fees], 0)" },
    { label:"Pipeline Value", formula:'CALCULATE(SUM(deal_analysis[GDV]), property_leads[Status] IN {"Viewing Booked","Under Offer"})' },
    { label:"Conversion Rate %", formula:'DIVIDE(CALCULATE(COUNTROWS(deal_matching), deal_matching[Outcome]="Completed"), COUNTROWS(deal_matching), 0)' },
  ];

  const barH = (val, max, col) => (
    <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:6 }}>
      <div style={{ flex:1, height:18, background:"var(--color-background-secondary)", borderRadius:3, overflow:"hidden" }}>
        <div style={{ width:`${(val/max)*100}%`, height:"100%", background:col, borderRadius:3 }} />
      </div>
      <span style={{ fontSize:12, minWidth:36, textAlign:"right", color:"var(--color-text-secondary)" }}>{val}</span>
    </div>
  );

  return (
    <div>
      <SectionHeader num="4" title="Power BI Dashboard Guide" subtitle="5 dashboards built from your real CSV data — with DAX formulas and setup steps" />

      {/* Tab Nav */}
      <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:20 }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id)} style={{
            padding:"7px 14px", borderRadius:20, fontSize:13, fontWeight: activeTab===t.id ? 500 : 400,
            background: activeTab===t.id ? "#0D1B3E" : "var(--color-background-secondary)",
            color: activeTab===t.id ? "#C9A84C" : "var(--color-text-primary)",
            border: activeTab===t.id ? "none" : "0.5px solid var(--color-border-tertiary)",
            cursor:"pointer"
          }}>{t.icon} {t.label}</button>
        ))}
      </div>

      {/* EXECUTIVE */}
      {activeTab === "executive" && (
        <div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit, minmax(130px, 1fr))", gap:10, marginBottom:20 }}>
            <KPICard icon="🏠" label="Total Deals" value={kpis.totalDeals} sub="100 properties" />
            <KPICard icon="💰" label="Total Fees" value="£498k" sub="Sourcing pipeline" />
            <KPICard icon="👥" label="Active Investors" value={kpis.activeInvestors} sub="of 50 total" />
            <KPICard icon="✅" label="Deals Completed" value={kpis.completed} sub="25% conversion" />
            <KPICard icon="📈" label="Avg ROI %" value={`${kpis.avgROI}%`} sub="Portfolio average" />
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
            <div style={{ background:"var(--color-background-primary)", border:"0.5px solid var(--color-border-tertiary)", borderRadius:"var(--border-radius-lg)", padding:16 }}>
              <p style={{ fontSize:13, fontWeight:500, marginBottom:12 }}>Fees by Month (£)</p>
              {feesByMonth.map(({ m, v }) => (
                <div key={m} style={{ display:"flex", alignItems:"center", gap:8, marginBottom:6 }}>
                  <span style={{ fontSize:11, width:24, color:"var(--color-text-secondary)" }}>{m}</span>
                  <div style={{ flex:1, height:14, background:"var(--color-background-secondary)", borderRadius:3, overflow:"hidden" }}>
                    <div style={{ width:`${(v/51000)*100}%`, height:"100%", background:"#1A7F8E", borderRadius:3 }} />
                  </div>
                  <span style={{ fontSize:11, color:"var(--color-text-secondary)", minWidth:40, textAlign:"right" }}>£{(v/1000).toFixed(0)}k</span>
                </div>
              ))}
            </div>
            <div style={{ background:"var(--color-background-primary)", border:"0.5px solid var(--color-border-tertiary)", borderRadius:"var(--border-radius-lg)", padding:16 }}>
              <p style={{ fontSize:13, fontWeight:500, marginBottom:12 }}>Deals by Status</p>
              {dealsByStatus.map(({ s, n, col }) => (
                <div key={s} style={{ display:"flex", alignItems:"center", gap:8, marginBottom:8 }}>
                  <div style={{ width:10, height:10, borderRadius:2, background:col, flexShrink:0 }} />
                  <span style={{ fontSize:12, flex:1, color:"var(--color-text-secondary)" }}>{s}</span>
                  {barH(n, 32, col)}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* DEALS */}
      {activeTab === "deals" && (
        <div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16, marginBottom:16 }}>
            <div style={{ background:"var(--color-background-primary)", border:"0.5px solid var(--color-border-tertiary)", borderRadius:"var(--border-radius-lg)", padding:16 }}>
              <p style={{ fontSize:13, fontWeight:500, marginBottom:12 }}>Avg ROI % by Area</p>
              {roiByArea.map(({ area, roi }) => (
                <div key={area} style={{ display:"flex", alignItems:"center", gap:8, marginBottom:7 }}>
                  <span style={{ fontSize:11, width:80, color:"var(--color-text-secondary)" }}>{area}</span>
                  <div style={{ flex:1, height:16, background:"var(--color-background-secondary)", borderRadius:3, overflow:"hidden" }}>
                    <div style={{ width:`${(roi/25)*100}%`, height:"100%", background: roi>=18?"#1E8449":roi>=15?"#1A7F8E":"#378ADD", borderRadius:3 }} />
                  </div>
                  <span style={{ fontSize:12, fontWeight:500, minWidth:36, textAlign:"right", color:"var(--color-text-secondary)" }}>{roi}%</span>
                </div>
              ))}
            </div>
            <div style={{ background:"var(--color-background-primary)", border:"0.5px solid var(--color-border-tertiary)", borderRadius:"var(--border-radius-lg)", padding:16 }}>
              <p style={{ fontSize:13, fontWeight:500, marginBottom:12 }}>Strategy Analysis</p>
              {strategyData.map(({ s, n, avgROI }) => (
                <div key={s} style={{ display:"flex", alignItems:"center", gap:8, marginBottom:10, padding:"8px 0", borderBottom:"0.5px solid var(--color-border-tertiary)" }}>
                  <span style={{ fontSize:12, fontWeight:500, width:36 }}>{s}</span>
                  <div style={{ flex:1 }}>
                    <div style={{ height:8, background:"var(--color-background-secondary)", borderRadius:4, overflow:"hidden", marginBottom:4 }}>
                      <div style={{ width:`${(n/42)*100}%`, height:"100%", background:"#0D1B3E", borderRadius:4 }} />
                    </div>
                    <span style={{ fontSize:11, color:"var(--color-text-secondary)" }}>{n} deals</span>
                  </div>
                  <span style={{ fontSize:13, fontWeight:500, color: avgROI>=20?"#1E8449":avgROI>=15?"#D4850D":"#378ADD", minWidth:44 }}>{avgROI}% ROI</span>
                </div>
              ))}
            </div>
          </div>
          <div style={{ background:"#E6F1FB", borderRadius:"var(--border-radius-md)", padding:"12px 16px", fontSize:13, color:"#0C447C" }}>
            <strong>Power BI Chart Types:</strong> ROI by Area → Clustered Bar | Strategy → Column Chart with secondary Avg ROI line | Profit by Area → Bar + data labels | Scatter: AI Score vs ROI% sized by Profit
          </div>
        </div>
      )}

      {/* INVESTORS */}
      {activeTab === "investors" && (
        <div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit, minmax(130px, 1fr))", gap:10, marginBottom:16 }}>
            <KPICard icon="👥" label="Active Investors" value="42" />
            <KPICard icon="🎯" label="Avg Match Score" value="74%" />
            <KPICard icon="🔄" label="Conversion Rate" value="25%" />
            <KPICard icon="⭐" label="Top Investor Deals" value="14" sub="Sarah Blackwell" />
          </div>
          <div style={{ background:"var(--color-background-primary)", border:"0.5px solid var(--color-border-tertiary)", borderRadius:"var(--border-radius-lg)", padding:16 }}>
            <p style={{ fontSize:13, fontWeight:500, marginBottom:12 }}>Investors by Strategy</p>
            {[
              { s:"BTL", n:21, col:"#378ADD" },{ s:"Flip", n:11, col:"#EF9F27" },
              { s:"HMO", n:9, col:"#1D9E75" },{ s:"BRRR", n:9, col:"#7F77DD" }
            ].map(({ s, n, col }) => (
              <div key={s} style={{ display:"flex", alignItems:"center", gap:10, marginBottom:10 }}>
                <span style={{ fontSize:12, width:40 }}>{s}</span>
                <div style={{ flex:1, height:20, background:"var(--color-background-secondary)", borderRadius:4, overflow:"hidden" }}>
                  <div style={{ width:`${(n/21)*100}%`, height:"100%", background:col, borderRadius:4, display:"flex", alignItems:"center", paddingLeft:8 }}>
                    <span style={{ fontSize:11, fontWeight:500, color:"#fff" }}>{n}</span>
                  </div>
                </div>
                <span style={{ fontSize:12, color:"var(--color-text-secondary)" }}>{Math.round(n/42*100)}%</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* RISK */}
      {activeTab === "risk" && (
        <div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit, minmax(130px, 1fr))", gap:10, marginBottom:16 }}>
            <KPICard icon="🟢" label="Low Risk" value="42" color="#1E8449" sub="42% of portfolio" />
            <KPICard icon="🟡" label="Medium Risk" value="40" color="#D4850D" sub="40% of portfolio" />
            <KPICard icon="🔴" label="High Risk" value="18" color="#C0392B" sub="18% — requires review" />
            <KPICard icon="⚠️" label="AML Pending" value="7" sub="Investors awaiting check" />
          </div>
          <div style={{ background:"var(--color-background-primary)", border:"0.5px solid var(--color-border-tertiary)", borderRadius:"var(--border-radius-lg)", padding:16, marginBottom:12 }}>
            <p style={{ fontSize:13, fontWeight:500, marginBottom:12 }}>Risk Distribution</p>
            <div style={{ display:"flex", height:28, borderRadius:4, overflow:"hidden", gap:2, marginBottom:10 }}>
              {riskDist.map(({ r, n, col }) => (
                <div key={r} style={{ flex:n, background:col, display:"flex", alignItems:"center", justifyContent:"center" }}>
                  <span style={{ fontSize:11, color:"#fff", fontWeight:500 }}>{r} {n}%</span>
                </div>
              ))}
            </div>
            <p style={{ fontSize:12, color:"var(--color-text-secondary)" }}>18 high-risk deals require action before investor distribution. Review comparables and vendor verification on all HIGH flags.</p>
          </div>
          <div style={{ background:"#FCEBEB", borderRadius:"var(--border-radius-md)", padding:"12px 16px", fontSize:13, color:"#501313" }}>
            <strong>Power BI:</strong> Risk donut chart (3 segments) | Risk trend line (month-by-month) | AML status bar | Scatter: AI Score vs ROI%, coloured by Risk Level
          </div>
        </div>
      )}

      {/* REVENUE */}
      {activeTab === "revenue" && (
        <div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit, minmax(130px, 1fr))", gap:10, marginBottom:16 }}>
            <KPICard icon="💰" label="Total Fees" value="£498k" color="#1E8449" />
            <KPICard icon="✅" label="Collected" value="£287k" color="#1E8449" sub="57.6% rate" />
            <KPICard icon="⏳" label="Outstanding" value="£211k" color="#D4850D" sub="Pending payment" />
            <KPICard icon="📋" label="Avg Fee/Deal" value="£4,985" />
          </div>
          <div style={{ background:"var(--color-background-primary)", border:"0.5px solid var(--color-border-tertiary)", borderRadius:"var(--border-radius-lg)", padding:16 }}>
            <p style={{ fontSize:13, fontWeight:500, marginBottom:12 }}>Fee Collection Rate — Monthly</p>
            {feesByMonth.map(({ m, v }) => {
              const collected = Math.round(v * 0.72);
              const pct = Math.round((collected/v)*100);
              return (
                <div key={m} style={{ display:"flex", alignItems:"center", gap:8, marginBottom:7 }}>
                  <span style={{ fontSize:11, width:24, color:"var(--color-text-secondary)" }}>{m}</span>
                  <div style={{ flex:1, height:16, background:"var(--color-background-secondary)", borderRadius:3, overflow:"hidden" }}>
                    <div style={{ width:`${pct}%`, height:"100%", background:"#1E8449", borderRadius:3 }} />
                  </div>
                  <span style={{ fontSize:11, color:"var(--color-text-secondary)", minWidth:30 }}>{pct}%</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SETUP */}
      {activeTab === "setup" && (
        <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
          <div style={{ background:"var(--color-background-secondary)", borderRadius:"var(--border-radius-lg)", padding:16 }}>
            <p style={{ fontWeight:500, fontSize:14, marginBottom:12 }}>Step 1 — Import your CSVs</p>
            {["property_leads.csv","deal_analysis.csv","investor_buyers.csv","deal_matching.csv","sourcing_fees.csv"].map(f => (
              <div key={f} style={{ display:"flex", alignItems:"center", gap:10, padding:"8px 0", borderBottom:"0.5px solid var(--color-border-tertiary)" }}>
                <span style={{ fontSize:16 }}>📄</span>
                <span style={{ fontSize:13, fontFamily:"var(--font-mono)", color:"var(--color-text-primary)" }}>{f}</span>
                <span style={{ fontSize:11, color:"var(--color-text-secondary)", marginLeft:"auto" }}>Get Data → Text/CSV</span>
              </div>
            ))}
          </div>
          <div style={{ background:"var(--color-background-secondary)", borderRadius:"var(--border-radius-lg)", padding:16 }}>
            <p style={{ fontWeight:500, fontSize:14, marginBottom:12 }}>Step 2 — Set Relationships (Model View)</p>
            {[
              ["deal_analysis","Property_ID","property_leads","Property_ID"],
              ["deal_matching","Deal_ID","deal_analysis","Deal_ID"],
              ["deal_matching","Investor_ID","investor_buyers","Investor_ID"],
              ["sourcing_fees","Deal_ID","deal_analysis","Deal_ID"],
              ["sourcing_fees","Investor_ID","investor_buyers","Investor_ID"],
            ].map(([t1,c1,t2,c2],i) => (
              <div key={i} style={{ fontSize:12, fontFamily:"var(--font-mono)", padding:"6px 0", borderBottom:"0.5px solid var(--color-border-tertiary)", color:"var(--color-text-secondary)" }}>
                {t1}[{c1}] → {t2}[{c2}] <span style={{ color:"#1A7F8E" }}>Many:One</span>
              </div>
            ))}
          </div>
          <div style={{ background:"#1A2535", borderRadius:"var(--border-radius-lg)", padding:16 }}>
            <p style={{ fontWeight:500, fontSize:13, marginBottom:12, color:"#C9A84C" }}>Step 3 — DAX Measures (New Measure)</p>
            {dax.map(({ label, formula }) => (
              <div key={label} style={{ marginBottom:10 }}>
                <div style={{ fontSize:11, color:"#7ECFDF", marginBottom:2 }}>{label}</div>
                <div style={{ fontSize:11, fontFamily:"monospace", color:"#AABBCC", lineHeight:1.6 }}>{formula}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ── PORTFOLIO & SUBMISSION GUIDE ──────────────────────────────────
function PortfolioGuide() {
  const items = [
    { icon:"🏆", title:"Nebius AI Builders Challenge", desc:"3 live AI agents · Nebius Studio integration · AI governance audit trail · 5-table data model · Full-stack build", tags:["Innovation","Real-World Impact","Technical Depth"] },
    { icon:"📊", title:"Power BI Portfolio Piece", desc:"Star schema · 5 dashboards · 10 DAX measures · Executive KPIs · Risk & Revenue analytics · Drill-through pages", tags:["Data Modelling","DAX","Dashboard Design"] },
    { icon:"💻", title:"Replit Application", desc:"React frontend · Node.js backend · Supabase DB · AI agents · Authentication · CSV export · Deployed URL", tags:["Full-Stack","Deployed","Live Demo"] },
    { icon:"🎙️", title:"Interview Talking Point", desc:"'I built an AI property platform covering data architecture, AI agents, risk management, compliance, and Power BI — all from one project.'", tags:["Business Analysis","Product Management","AI"] },
    { icon:"🛡️", title:"TPRM / GRC Evidence", desc:"AML tracking · ICO data compliance · AI audit trail · EU AI Act Art. 12 logging · Risk classification engine · Due diligence records", tags:["AML","ICO","EU AI Act","Risk"] },
  ];

  return (
    <div>
      <SectionHeader num="5" title="Portfolio & Submission Guide" subtitle="5 ways this one project opens doors across property, data, AI, and GRC careers" />
      <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
        {items.map(({ icon, title, desc, tags }) => (
          <div key={title} style={{ background:"var(--color-background-primary)", border:"0.5px solid var(--color-border-tertiary)", borderRadius:"var(--border-radius-lg)", padding:"16px 18px", display:"flex", gap:14 }}>
            <span style={{ fontSize:28, lineHeight:1 }}>{icon}</span>
            <div>
              <p style={{ fontWeight:500, fontSize:15, marginBottom:6 }}>{title}</p>
              <p style={{ fontSize:13, color:"var(--color-text-secondary)", marginBottom:10, lineHeight:1.6 }}>{desc}</p>
              <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                {tags.map(t => <Badge key={t} label={t} bg="#E6F1FB" color="#0C447C" />)}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── MAIN APP ──────────────────────────────────────────────────────
export default function PropertyPilotAI() {
  const [activeSection, setActiveSection] = useState("agent1");
  const [agent1Result, setAgent1Result] = useState(null);

  const nav = [
    { id:"agent1", label:"Deal Analyser", icon:"🔍", sub:"Agent 1" },
    { id:"agent2", label:"Investor Matcher", icon:"👥", sub:"Agent 2" },
    { id:"agent3", label:"Summary Generator", icon:"📝", sub:"Agent 3" },
    { id:"powerbi", label:"Power BI Guide", icon:"📊", sub:"Dashboards" },
    { id:"portfolio", label:"Portfolio Guide", icon:"🏆", sub:"Submission" },
  ];

  return (
    <div style={{ fontFamily:"var(--font-sans)", maxWidth:860, margin:"0 auto" }}>
      <h2 className="sr-only">PropertyPilot AI — AI Property Intelligence Platform with three agents, Power BI guide, and portfolio submission guide</h2>

      {/* Header */}
      <div style={{ background:"#0D1B3E", borderRadius:"var(--border-radius-lg)", padding:"18px 24px", marginBottom:20, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <div>
          <div style={{ fontSize:20, fontWeight:500, color:"#C9A84C", letterSpacing:0.5 }}>PropertyPilot AI™</div>
          <div style={{ fontSize:12, color:"rgba(255,255,255,0.65)", marginTop:2 }}>AI Property Intelligence Platform · Nebius AI Builders Challenge 2025</div>
        </div>
        <div style={{ display:"flex", gap:6 }}>
          <span style={{ fontSize:11, background:"rgba(201,168,76,0.2)", color:"#C9A84C", padding:"4px 10px", borderRadius:20 }}>3 AI Agents</span>
          <span style={{ fontSize:11, background:"rgba(26,127,142,0.2)", color:"#7ECFDF", padding:"4px 10px", borderRadius:20 }}>5 Dashboards</span>
        </div>
      </div>

      {/* Nav */}
      <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:24 }}>
        {nav.map(n => (
          <button key={n.id} onClick={() => setActiveSection(n.id)} style={{
            padding:"8px 14px", borderRadius:20, fontSize:13, cursor:"pointer",
            background: activeSection===n.id ? "#0D1B3E" : "var(--color-background-secondary)",
            color: activeSection===n.id ? "#C9A84C" : "var(--color-text-primary)",
            border: activeSection===n.id ? "none" : "0.5px solid var(--color-border-tertiary)",
            fontWeight: activeSection===n.id ? 500 : 400,
            display:"flex", flexDirection:"column", alignItems:"center", gap:1
          }}>
            <span>{n.icon} {n.label}</span>
            <span style={{ fontSize:10, opacity:0.7 }}>{n.sub}</span>
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={{ background:"var(--color-background-primary)", border:"0.5px solid var(--color-border-tertiary)", borderRadius:"var(--border-radius-lg)", padding:"24px" }}>
        {activeSection === "agent1" && <Agent1 onResult={setAgent1Result} />}
        {activeSection === "agent2" && <Agent2 prefill={agent1Result} />}
        {activeSection === "agent3" && <Agent3 prefill={agent1Result} />}
        {activeSection === "powerbi" && <PowerBIDashboard />}
        {activeSection === "portfolio" && <PortfolioGuide />}
      </div>

      {/* Footer */}
      <div style={{ textAlign:"center", padding:"14px 0", fontSize:12, color:"var(--color-text-secondary)" }}>
        PropertyPilot AI™ · FaithfulordStudio™ · Faith Growth Agency · London SE1 · Nebius AI Challenge 2025
      </div>
    </div>
  );
}
